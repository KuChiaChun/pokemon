import javax.swing.JFrame;
//���3A �j�ήm 104403019
public class PokemonFrameTest {
	public static void main(String[] args) {
		PokemonFrame pokemonframe = new PokemonFrame();
		pokemonframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pokemonframe.setSize(800,700);
		pokemonframe.setResizable(false);
		pokemonframe.setVisible(true);
	} 

}
